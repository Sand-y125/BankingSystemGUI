package BankingSystem;

//Account class(sub class) that extends Customer(super class) and handles account operations
public class Account extends Customer {
	private int balance;
    private int accountNumber;
    
    // Constructor to initialize account with details
    public Account(String fName, String lName, int accountNumber, int balance) {
        setFirstName(fName);
        setLastName(lName);
        this.accountNumber = accountNumber;
        this.balance = balance;
    }
 // Getter for current balance
    public int getBalance() {
        return balance;
    }
    

    // Getter for account number
    public int getAccountNum() {
        return accountNumber;
    }

    // Method to deposit amount into account
    public void deposit(int amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(amount + "deposited to account" + accountNumber);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // Method to withdraw amount from account
    public void withdraw(int amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println(amount + " withdrawn from account " + accountNumber);
        } else {
            System.out.println("Insufficient balance");
        }
    }

}
