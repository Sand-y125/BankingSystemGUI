package BankingSystem;

//Transaction Class to handle money transfers between two accounts
public class Transaction {
	 public void transfer(Account source, Account destination, int amount) {
	        if (amount > 0 && amount <= source.getBalance()) {
	            source.withdraw(amount);
	            destination.deposit(amount);
	            System.out.println("Transferred " + amount + " from account " + source.getAccountNum() +
	                    " to account " + destination.getAccountNum());
	        } else {
	            System.out.println("insufficient balance");
	        }
	    }

}
