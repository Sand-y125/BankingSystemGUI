package BankingSystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

public class GUI extends JFrame {

	private JPanel contentPane;
    private ReadAccounts reader;

    private Transaction transferObject = new Transaction();
    private StringBuilder sbAllData = new StringBuilder();
    private LinkedList<Account> globalAccounts;

    private JLabel showAllData;
    private JButton showAllButton, depositButton, withdrawButton, transferButton;
    private JTextField accDeposit, depositInput;
    private JTextField accwithdraw;
    private JTextField withdrawInput;
    private JTextField sourcetransfer;
    private JTextField destinationtransfer;
    private JTextPane txtpnAmount;
    private JTextField transferInput;

    // Launch the application
    public static void main(String[] args) {
        LinkedList<Account> accounts;
        ReadAccounts reader = new ReadAccounts("Accounts.csv");
        accounts = reader.getAccounts(); // helps to loads accounts from file

        EventQueue.invokeLater(() -> {
            try {
                GUI frame = new GUI(accounts); // pass accounts list to GUI
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public GUI(LinkedList<Account> accounts) {
    	this.reader = new ReadAccounts("Accounts.csv");
    	
    	//JFrame setup
        setTitle("Banking System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(64, 128, 128));
        contentPane.setLayout(null);
        setContentPane(contentPane);
        
        //Title Label    
        JLabel titleLabel = new JLabel("Banking System");
        titleLabel.setFont(new Font("Century Schoolbook", Font.BOLD, 32));
        titleLabel.setForeground(new Color(0, 0, 0));
        titleLabel.setBounds(232, 10, 400, 40); 
        contentPane.add(titleLabel);

        globalAccounts = accounts;// Store accounts globally for GUI use

        // Label to show all account data
        showAllData = new JLabel();
        showAllData.setFont(new Font("Yu Gothic Light", Font.BOLD, 20));
        showAllData.setBackground(new Color(0, 128, 0));
        showAllData.setBounds(131, 40, 480, 200);
        showAllData.setForeground(new Color(0, 0, 0));
        contentPane.add(showAllData);
        updateAccountData(); // Display account data initially


        // Buttons initialization and design
        showAllButton = new JButton("Show All");
        showAllButton.setForeground(new Color(255, 255, 255));
        showAllButton.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 12));
        showAllButton.setBackground(new Color(128, 0, 64));
        depositButton = new JButton("Deposit");
        depositButton.setForeground(new Color(255, 255, 255));
        depositButton.setFont(new Font("Arial Black", Font.BOLD, 16));
        depositButton.setBackground(new Color(128, 64, 64));
        withdrawButton = new JButton("Withdraw");
        withdrawButton.setForeground(new Color(255, 255, 255));
        withdrawButton.setFont(new Font("Arial Black", Font.BOLD, 16));
        withdrawButton.setBackground(new Color(0, 64, 128));
        transferButton = new JButton("Transfer");
        transferButton.setForeground(new Color(255, 255, 255));
        transferButton.setFont(new Font("Arial Black", Font.BOLD, 16));
        transferButton.setBackground(new Color(128, 128, 0));

        showAllButton.setBounds(636, 157, 100, 30);
        depositButton.setBounds(36, 248, 118, 49);
        withdrawButton.setBounds(36, 338, 123, 49);
        transferButton.setBounds(36, 421, 130, 49);

        accDeposit = new JTextField("");
        accDeposit.setBackground(new Color(192, 192, 192));
        accDeposit.setFont(new Font("Tahoma", Font.PLAIN, 15));
        depositInput = new JTextField("");
        depositInput.setBackground(new Color(192, 192, 192));
        accDeposit.setBounds(329, 248, 132, 36);
        depositInput.setBounds(636, 248, 123, 36);

        contentPane.add(showAllButton);
        contentPane.add(depositButton);
        contentPane.add(withdrawButton);
        contentPane.add(transferButton);
        contentPane.add(accDeposit);
        contentPane.add(depositInput);
        
        JTextPane txtpnEnterDepositeAccount = new JTextPane();
        txtpnEnterDepositeAccount.setForeground(new Color(255, 255, 255));
        txtpnEnterDepositeAccount.setFont(new Font("Calibri", Font.BOLD, 17));
        txtpnEnterDepositeAccount.setBackground(new Color(64, 128, 128));
        txtpnEnterDepositeAccount.setText("Enter Amount : ");
        txtpnEnterDepositeAccount.setBounds(492, 253, 130, 31);
        contentPane.add(txtpnEnterDepositeAccount);
        
        JTextPane txtpnEnterAccNumber = new JTextPane();
        txtpnEnterAccNumber.setForeground(new Color(255, 255, 255));
        txtpnEnterAccNumber.setText("Enter Acc Number :");
        txtpnEnterAccNumber.setFont(new Font("Calibri", Font.BOLD, 17));
        txtpnEnterAccNumber.setBackground(new Color(64, 128, 128));
        txtpnEnterAccNumber.setBounds(176, 258, 164, 31);
        contentPane.add(txtpnEnterAccNumber);
        
        JTextPane txtpnFromAcc = new JTextPane();
        txtpnFromAcc.setForeground(new Color(255, 255, 255));
        txtpnFromAcc.setText("From Acc :");
        txtpnFromAcc.setFont(new Font("Cambria", Font.BOLD, 17));
        txtpnFromAcc.setBackground(new Color(64, 128, 128));
        txtpnFromAcc.setBounds(176, 439, 89, 31);
        contentPane.add(txtpnFromAcc);
        
        accwithdraw = new JTextField("");
        accwithdraw.setBackground(new Color(192, 192, 192));
        accwithdraw.setFont(new Font("Tahoma", Font.PLAIN, 15));
        accwithdraw.setBounds(329, 346, 132, 36);
        contentPane.add(accwithdraw);
        
        JTextPane txtpnEnterDepositeAccount_1 = new JTextPane();
        txtpnEnterDepositeAccount_1.setForeground(new Color(255, 255, 255));
        txtpnEnterDepositeAccount_1.setText("Enter Amount : ");
        txtpnEnterDepositeAccount_1.setFont(new Font("Cambria", Font.BOLD, 17));
        txtpnEnterDepositeAccount_1.setBackground(new Color(64, 128, 128));
        txtpnEnterDepositeAccount_1.setBounds(492, 349, 123, 31);
        contentPane.add(txtpnEnterDepositeAccount_1);
        
        withdrawInput = new JTextField("");
        withdrawInput.setBackground(new Color(192, 192, 192));
        withdrawInput.setBounds(636, 348, 123, 36);
        contentPane.add(withdrawInput);
        
        JTextPane txtpnEnterAccNumber_1_1 = new JTextPane();
        txtpnEnterAccNumber_1_1.setForeground(new Color(255, 255, 255));
        txtpnEnterAccNumber_1_1.setText("Enter Acc Number :");
        txtpnEnterAccNumber_1_1.setFont(new Font("Calibri", Font.BOLD, 17));
        txtpnEnterAccNumber_1_1.setBackground(new Color(64, 128, 128));
        txtpnEnterAccNumber_1_1.setBounds(169, 356, 156, 31);
        contentPane.add(txtpnEnterAccNumber_1_1);
        
        sourcetransfer = new JTextField("");
        sourcetransfer.setBackground(new Color(192, 192, 192));
        sourcetransfer.setFont(new Font("Tahoma", Font.PLAIN, 15));
        sourcetransfer.setBounds(275, 434, 118, 36);
        contentPane.add(sourcetransfer);
        
        JTextPane txtpnToAcc = new JTextPane();
        txtpnToAcc.setForeground(new Color(255, 255, 255));
        txtpnToAcc.setText("To Acc :");
        txtpnToAcc.setFont(new Font("Cambria", Font.BOLD, 17));
        txtpnToAcc.setBackground(new Color(64, 128, 128));
        txtpnToAcc.setBounds(403, 439, 72, 31);
        contentPane.add(txtpnToAcc);
        
        destinationtransfer = new JTextField("");
        destinationtransfer.setBackground(new Color(192, 192, 192));
        destinationtransfer.setBounds(477, 431, 123, 36);
        contentPane.add(destinationtransfer);
        
        txtpnAmount = new JTextPane();
        txtpnAmount.setForeground(new Color(255, 255, 255));
        txtpnAmount.setText("Amount:");
        txtpnAmount.setFont(new Font("Calibri", Font.BOLD, 17));
        txtpnAmount.setBackground(new Color(64, 128, 128));
        txtpnAmount.setBounds(615, 439, 72, 31);
        contentPane.add(txtpnAmount);
        
        transferInput = new JTextField("");
        transferInput.setBackground(new Color(192, 192, 192));
        transferInput.setFont(new Font("Tahoma", Font.PLAIN, 15));
        transferInput.setBounds(687, 429, 89, 36);
        contentPane.add(transferInput);

        //  Adding Action Listener to buttons
        HandlerClass handler = new HandlerClass();
        showAllButton.addActionListener(handler);
        depositButton.addActionListener(handler);
        withdrawButton.addActionListener(handler);
        transferButton.addActionListener(handler);
    }
    //updateAccountData method for Updating the JLabel with all account data from globalAccounts
    private void updateAccountData() {
        sbAllData.setLength(0);
        for (Account acc : globalAccounts) {
            sbAllData.append(acc.getFirstName())
                .append(" ")
                .append(acc.getLastName())
                .append("\tAccount Number: ")
                .append(acc.getAccountNum())
                .append("\tBalance: ")
                .append(acc.getBalance())
                .append("\n");
        }
     // Format string with HTML for multiline display in JLabel here the account.csv file content
        showAllData.setText("<html>" + sbAllData.toString().replaceAll("\n", "<br>") + "</html>");
    }
    
    

    // Handles button actions for Show All, Deposit, Withdraw, Transfer
    private class HandlerClass implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == showAllButton) {
                updateAccountData();
                JOptionPane.showMessageDialog(null, "ALL DATA", "Success", JOptionPane.INFORMATION_MESSAGE);


            } else if (e.getSource() == depositButton) {
                try {
                    int accNum = Integer.parseInt(accDeposit.getText().trim());
                    int amount = Integer.parseInt(depositInput.getText().trim());

                    Account found = null;
                    
                    // Find account by account number
                    for (Account acc : globalAccounts) {
                        if (acc.getAccountNum() == accNum) {
                            found = acc;
                            break;
                        }
                    }

                    if (found != null) {
                        found.deposit(amount); // Deposit amount to account
                        reader.saveAccounts(globalAccounts); // Save updated accounts to file
                        updateAccountData();
                        JOptionPane.showMessageDialog(null, "Balance deposite successfully", "Success", JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        JOptionPane.showMessageDialog(null, "Account number not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(null, "Please enter valid numbers!", "Input Error", JOptionPane.ERROR_MESSAGE);
                } 
            }
               
             else if (e.getSource() == withdrawButton) {
                try {
                    int accNum = Integer.parseInt(accwithdraw.getText().trim());
                    int amount = Integer.parseInt(withdrawInput.getText().trim());

                    Account found = null;
                    // Find account by account number
                    for (Account acc : globalAccounts) {
                        if (acc.getAccountNum() == accNum) {
                            found = acc;
                            break;
                        }
                    }

                    if (found != null) {
                        if (amount > found.getBalance()) {
                            JOptionPane.showMessageDialog(null, "Insufficient balance.", "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            found.withdraw(amount);// Withdraw amount from account
                            reader.saveAccounts(globalAccounts);// Save updated accounts
                            updateAccountData();
                            JOptionPane.showMessageDialog(null, "withdraw balance successfully", "Success", JOptionPane.INFORMATION_MESSAGE);

                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Account number not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(null, "Please enter valid numeric values", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            } else if (e.getSource() == transferButton) {
                try {
                    int fromAccNum = Integer.parseInt(sourcetransfer.getText().trim());
                    int toAccNum = Integer.parseInt(destinationtransfer.getText().trim());
                    int amount = Integer.parseInt(transferInput.getText().trim());

                    Account fromAcc = null;
                    Account toAcc = null;
                    
                    // Find both accounts
                    for (Account acc : globalAccounts) {
                        if (acc.getAccountNum() == fromAccNum) {
                            fromAcc = acc;
          
                        }
                        if (acc.getAccountNum() == toAccNum) {
                            toAcc = acc;
                        }
                    }

                    if (fromAcc == null || toAcc == null) {
                        JOptionPane.showMessageDialog(null, "account numbers not found.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (amount > fromAcc.getBalance()) {
                        JOptionPane.showMessageDialog(null, "Insufficient balance", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        transferObject.transfer(fromAcc, toAcc, amount);// Perform transfer from one account to another
                        reader.saveAccounts(globalAccounts); // Save updated accounts
                        updateAccountData();
                        JOptionPane.showMessageDialog(null, "Balance transfer successfully", "Success", JOptionPane.INFORMATION_MESSAGE);

                    }
                } catch (NumberFormatException nfe) {
                    JOptionPane.showMessageDialog(null, "Please enter valid numeric values", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}



