package BankingSystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedList;

// ReadAccounts Class to read and save account data from file
    public class ReadAccounts {
    private String url; // file path of the accounts data file

    // Constructor to set the file path or URL
    public ReadAccounts(String url) {
        this.url = url;
    }

    // Reads account data from the file and returns it as a LinkedList of Account objects
    public LinkedList<Account> getAccounts() {
    	// list to store accounts
        LinkedList<Account> accounts = new LinkedList<>(); 
        
        try (BufferedReader reader = new BufferedReader(new FileReader(url))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\t"); // split line by tab character
                if (parts.length == 4) { 
                    try {
                        String fName = parts[0]; // first name from file
                        String lName = parts[1]; // last name from file
                        int accNum = Integer.parseInt(parts[2]); // account number parsed to Integer
                        int bal = Integer.parseInt(parts[3]); // balance parsed to Integer
                        accounts.add(new Account(fName, lName, accNum, bal)); // Create Account object and add it to the list

                    } catch (NumberFormatException e) {
                        // Handle invalid number format in account number or balance
                        System.out.println("Skipping line due to number format: " + line);
                    }
                } else {
                    // Handle incorrect line format (missing fields)
                    System.out.println("Skipping malformed line: " + line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading accounts: " + e.getMessage());
        }
        return accounts; // return list of accounts read from file
    }

    // Saves the list of accounts back to the file in tab-separated format
    public void saveAccounts(LinkedList<Account> accounts) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(url))) {
            for (Account acc : accounts) {
                writer.println(acc.getFirstName() + "\t" + acc.getLastName() + "\t" + acc.getAccountNum() + "\t" + acc.getBalance());
            }
        } catch (IOException e) {
            // Handle error while saving accounts to the file
            System.out.println("Error saving accounts: " + e.getMessage());
        }
    }
}
