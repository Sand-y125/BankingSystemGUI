package BankingSystem;

//Customer customer to store details like first and last name
public class Customer {
	private String firstName;
    private String lastName;
    
    // Getter for first name
    public String getFirstName() {
        return firstName;
    }
    // Setter for first name
    public void setFirstName(String fName) {
        this.firstName = fName;
    }
    
    // Getter for last name
    public String getLastName() {
        return lastName;
    }
    // Setter for last name
    public void setLastName(String lName) {
        this.lastName = lName;
    }
}
