/**
 * 
 */
/**
 * 
 */
module BankingSystem {
	requires java.desktop;
}